#include "headers/Display.h"
using namespace std;
/**
 * The player class is abstract and so its functions don't need implementation.
 */
Display::Display() { }
/**
 * The player class is abstract and so its functions don't need implementation.
 */
Display::~Display() { }
