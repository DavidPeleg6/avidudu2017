#include <iostream>
#include "headers/Player.h"
using namespace std;
/**
 * The player class is abstract and so its functions don't need implementation.
 */
Player::Player() { }
/**
 * The player class is abstract and so its functions don't need implementation.
 */
Player::~Player() { }
